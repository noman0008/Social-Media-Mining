A big part of analysis was done on mySQL server...The query files are sometime too big to upload

Few other were done manually.